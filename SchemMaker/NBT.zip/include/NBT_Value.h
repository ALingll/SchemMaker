#pragma once

#include <iostream>
#include <variant>
#include <vector>
#include <map>
#include <type_traits>
#include <fstream>
#include <sstream>
#include <stdint.h>
#include <algorithm>
#include <functional>

#include <zlib.h>
#include <functional>


namespace NBT {

	std::string decompressString(const std::string&);

	extern class NBT_Value;

	using End		 = std::monostate;
	using Byte		 = int8_t;
	using Short		 = int16_t;
	using Int		 = int32_t;
	using Long		 = int64_t;
	using Float		 = float;
	using Double	 = double;
	using Byte_Array = std::vector<Byte>;
	using String	 = std::string;
	using List		 = std::vector<NBT_Value>;
	using Compound	 = std::map<String, NBT_Value>;
	using Int_Array	 = std::vector<Int>;
	using Long_Array = std::vector<Long>;

	template<typename T>
	concept NBT_Type =
		std::is_same_v<T, End		> ||
		std::is_same_v<T, Byte		> ||
		std::is_same_v<T, Short		> ||
		std::is_same_v<T, Int		> ||
		std::is_same_v<T, Long		> ||
		std::is_same_v<T, Float		> ||
		std::is_same_v<T, Double	> ||
		std::is_same_v<T, Byte_Array> ||
		std::is_same_v<T, String	> ||
		std::is_same_v<T, List		> ||
		std::is_same_v<T, Compound	> ||
		std::is_same_v<T, Int_Array	> ||
		std::is_same_v<T, Long_Array>;

	template<typename T>
	concept NBT_Not_Null =
		NBT_Type<T> &&
		!std::is_same_v<T, End>;

	template<typename T>
	concept NBT_Used_Type =
		std::is_integral_v<T> ||
		std::is_floating_point_v<T>;

	template<typename T>
	concept NBT_Surpported_Type =
		NBT_Type<T> || 
		NBT_Used_Type<T>;

	class NBT_Value {
	public:

		friend std::ifstream& operator>>(std::ifstream&, NBT_Value&);
		friend std::ofstream& operator<<(std::ofstream&, NBT_Value&);

		enum class tag {
			TAG_End			 = 0x00,
			TAG_Byte		 = 0x01,
			TAG_Short		 = 0x02,
			TAG_Int			 = 0x03,
			TAG_Long		 = 0x04,
			TAG_Float		 = 0x05,
			TAG_Double		 = 0x06,
			TAG_Byte_Array	 = 0x07,
			TAG_String		 = 0x08,
			TAG_List		 = 0x09,
			TAG_Compound	 = 0x0a,
			TAG_Int_Array	 = 0x0b,
			TAG_Long_Array	 = 0x0c
		};

		tag get_tag() const;

		static constexpr int use_gz = 0x0001;

	private:
		std::variant<
			End, Byte, Short,
			Int, Long, Float,
			Double, Byte_Array, String,
			List, Compound, Int_Array,
			Long_Array
		> _value;

		int _state;
		tag _list_type;

		NBT_Value& set_list_type(tag type) { _list_type = type; return *this; }

#pragma region get_binary_data

		static tag get_binary_tag(std::istringstream& is) {
			unsigned char v;
			is >> v;
			return (tag)v;
		}

		static Byte get_binary_byte(std::istringstream& is) {
			unsigned char bytes[1]{};
			is >> bytes[0];
			Byte v = static_cast<Byte>(bytes[0]);
			return v;
		}

		static Short get_binary_short(std::istringstream& is) {
			unsigned char bytes[2]{};
			is >> bytes[1] >> bytes[0];
			Short v = 
				(static_cast<Short>(bytes[1]) << 8) |
				static_cast<Short>(bytes[0]);
			return v;
		}

		static Int get_binary_int(std::istringstream& is) {
			unsigned char bytes[4]{};
			is >> bytes[3] >> bytes[2] >> bytes[1] >> bytes[0];
			Int v =
				(static_cast<Int>(bytes[3]) << 24) |
				(static_cast<Int>(bytes[2]) << 16) |
				(static_cast<Int>(bytes[1]) << 8) |
				static_cast<Int>(bytes[0]);
			return v;
		}

		static Long get_binary_long(std::istringstream& is) {
			unsigned char bytes[8]{};
			is >> bytes[7] >> bytes[6] >> bytes[5] >> bytes[4]
				>> bytes[3] >> bytes[2] >> bytes[1] >> bytes[0];
			Long v =
				(static_cast<Long>(bytes[7]) << 56) |
				(static_cast<Long>(bytes[6]) << 48) |
				(static_cast<Long>(bytes[5]) << 40) |
				(static_cast<Long>(bytes[4]) << 32) |
				(static_cast<Long>(bytes[3]) << 24) |
				(static_cast<Long>(bytes[2]) << 16) |
				(static_cast<Long>(bytes[1]) << 8) |
				static_cast<Long>(bytes[0]);
			return v;
		}

		static Float get_binary_float(std::istringstream& is) {
			unsigned char bytes[4]{};
			is >> bytes[3] >> bytes[2] >> bytes[1] >> bytes[0];
			uint32_t integer_value =
				(static_cast<uint32_t>(bytes[3]) << 24) |
				(static_cast<uint32_t>(bytes[2]) << 16) |
				(static_cast<uint32_t>(bytes[1]) << 8) |
				static_cast<uint32_t>(bytes[0]);
			Float v;
			std::memcpy(&v, &integer_value, sizeof(v));
			return v;
		}

		static Double get_binary_double(std::istringstream& is) {
			unsigned char bytes[8]{};
			is >> bytes[7] >> bytes[6] >> bytes[5] >> bytes[4]
				>> bytes[3] >> bytes[2] >> bytes[1] >> bytes[0];
			uint64_t integer_value =
				(static_cast<uint64_t>(bytes[7]) << 56) |
				(static_cast<uint64_t>(bytes[6]) << 48) |
				(static_cast<uint64_t>(bytes[5]) << 40) |
				(static_cast<uint64_t>(bytes[4]) << 32) |
				(static_cast<uint64_t>(bytes[3]) << 24) |
				(static_cast<uint64_t>(bytes[2]) << 16) |
				(static_cast<uint64_t>(bytes[1]) << 8) |
				static_cast<uint64_t>(bytes[0]);
			Double v;
			std::memcpy(&v, &integer_value, sizeof(v));
			return v;
		}

		static Byte_Array get_binary_byte_array(std::istringstream& is) {
			Byte_Array v;
			for (auto len = get_binary_int(is); len > 0; len--) {
				v.push_back(get_binary_byte(is));
			}
			return v;
		}

		static String get_binary_string(std::istringstream& is) {

			Short len = get_binary_short(is);
			char c;
			String v{""};
			for (auto i = 0; i < len; i++) {
				is >> c;
				v.push_back(c);
			}
			return v;
		}

		static NBT_Value get_binary_list(std::istringstream& is) {
			auto current_tag = get_binary_tag(is);
			auto len = get_binary_int(is);
			List v(len);
			switch (current_tag)
			{
			case NBT::NBT_Value::tag::TAG_End:
				break;
			case NBT::NBT_Value::tag::TAG_Byte:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_byte(is); });
				break;
			case NBT::NBT_Value::tag::TAG_Short:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_short(is); });
				break;
			case NBT::NBT_Value::tag::TAG_Int:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_int(is); });
				break;
			case NBT::NBT_Value::tag::TAG_Long:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_long(is); });
				break;
			case NBT::NBT_Value::tag::TAG_Float:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_float(is); });
				break;
			case NBT::NBT_Value::tag::TAG_Double:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_double(is); });
				break;
			case NBT::NBT_Value::tag::TAG_Byte_Array:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_byte_array(is); });
				break;
			case NBT::NBT_Value::tag::TAG_String:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_string(is); });
				break;
			case NBT::NBT_Value::tag::TAG_List:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_list(is); });
				break;
			case NBT::NBT_Value::tag::TAG_Compound:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_compound(is); });
				break;
			case NBT::NBT_Value::tag::TAG_Int_Array:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_int_array(is); });
				break;
			case NBT::NBT_Value::tag::TAG_Long_Array:
				std::for_each(v.begin(), v.end(), [&](NBT_Value& e) {e = get_binary_long_array(is); });
				break;
			default:
				break;
			}
			return std::move(((NBT_Value)std::move(v)).set_list_type(current_tag));
		}

		static Compound get_binary_compound(std::istringstream& is) {
			Compound v;
			bool end_flag = false;
			while (!end_flag) {
				switch (get_binary_tag(is)) {
				case NBT::NBT_Value::tag::TAG_Byte: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_byte(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_Short: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_short(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_Int: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_int(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_Long: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_long(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_Float: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_float(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_Double: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_double(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_Byte_Array: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_byte_array(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_String: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_string(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_List: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_list(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_Compound: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_compound(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_Int_Array: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_int_array(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_Long_Array: {
					auto current_name = get_binary_string(is);
					v[current_name] = get_binary_long_array(is);
					break;
				}
				case NBT::NBT_Value::tag::TAG_End: default: {
					end_flag = true;
					break;
				}
				}
			}
			return std::move(v);
		}

		static Int_Array get_binary_int_array(std::istringstream& is) {
			Int_Array v;
			for (auto len = get_binary_int(is); len > 0; len--) {
				v.push_back(get_binary_int(is));
			}
			return v;
		}

		static Long_Array get_binary_long_array(std::istringstream& is) {
			Long_Array v;
			for (auto len = get_binary_int(is); len > 0; len--) {
				v.push_back(get_binary_long(is));
			}
			return v;
		}

#pragma endregion

#pragma region put_binary_data
public:
		static void put_binary_data(std::ostringstream& os, const NBT_Value& v) {
			struct {
				void put_binary_tag(std::ostringstream& os, tag _) {
					os << (unsigned char)_;
				}
				void operator()(std::ostringstream& os, const End& v, tag list_tag) {
					put_binary_tag(os, tag::TAG_End);
				}
				void operator()(std::ostringstream& os, const Byte& v, tag list_tag) {
					const unsigned char* bytes = reinterpret_cast<const unsigned char*>(&v);
					os << bytes[0];
				}
				void operator()(std::ostringstream& os, const Short& v, tag list_tag) {
					const unsigned char* bytes = reinterpret_cast<const unsigned char*>(&v);
					os << bytes[1] << bytes[0];
				}
				void operator()(std::ostringstream& os, const Int& v, tag list_tag) {
					const unsigned char* bytes = reinterpret_cast<const unsigned char*>(&v);
					os << bytes[3] << bytes[2] << bytes[1] << bytes[0];
				}
				void operator()(std::ostringstream& os, const Long& v, tag list_tag) {
					const unsigned char* bytes = reinterpret_cast<const unsigned char*>(&v);
					os << bytes[7] << bytes[6] << bytes[5] << bytes[4]
						<< bytes[3] << bytes[2] << bytes[1] << bytes[0];
				}
				void operator()(std::ostringstream& os, const Float& v, tag list_tag) {
					const unsigned char* bytes = reinterpret_cast<const unsigned char*>(&v);
					os << bytes[3] << bytes[2] << bytes[1] << bytes[0];
				}
				void operator()(std::ostringstream& os, const Double& v, tag list_tag) {
					const unsigned char* bytes = reinterpret_cast<const unsigned char*>(&v);
					os << bytes[7] << bytes[6] << bytes[5] << bytes[4]
						<< bytes[3] << bytes[2] << bytes[1] << bytes[0];
				}
				void operator()(std::ostringstream& os, const Byte_Array& v, tag list_tag) {
					this->operator()(os, (Int)v.size(), list_tag);
					for (auto& _ : v)
						this->operator()(os, _, list_tag);
				}
				void operator()(std::ostringstream& os, const String& v, tag list_tag) {
					uint16_t len = v.size();
					const unsigned char* bytes = reinterpret_cast<const unsigned char*>(&len);
					os << bytes[1] << bytes[0];
					for (auto& _ : v)
						this->operator()(os, (Byte)_, list_tag);
				}
				void operator()(std::ostringstream& os, const List& v, tag list_tag) {
					put_binary_tag(os, list_tag);
					this->operator()(os, (Int)v.size(), list_tag);
					for (auto& _ : v)
						put_binary_data(os, _);
				}
				void operator()(std::ostringstream& os, const Compound& v, tag list_tag) {
					for (const auto& [tag, value] : v) {
						put_binary_tag(os, value.get_tag());
						put_binary_data(os, NBT_Value(tag));
						put_binary_data(os, value);
					}
					put_binary_tag(os, tag::TAG_End);
				}
				void operator()(std::ostringstream& os, const Int_Array& v, tag list_tag) {
					this->operator()(os, (Int)v.size(), list_tag);
					for (auto& _ : v)
						this->operator()(os, _, list_tag);
				}
				void operator()(std::ostringstream& os, const Long_Array& v, tag list_tag) {
					this->operator()(os, (Int)v.size(), list_tag);
					for (auto& _ : v)
						this->operator()(os, _, list_tag);
				}
			}put_binary_visitor;
			return std::visit([&](auto&& _) {
				return put_binary_visitor(os, _, v._list_type);
				}, v._value);
		}

#pragma endregion


	public:

		NBT_Value() :_state(0), _list_type(tag::TAG_End) {}

		template<NBT_Surpported_Type T>
		explicit NBT_Value(const T& value, int state = 0) : _value(value), _state(state), _list_type(tag::TAG_End) {}

		explicit NBT_Value(const char* s, int state = 0) :_value(s), _state(state), _list_type(tag::TAG_End) {}

		NBT_Value(std::initializer_list<std::pair<std::string, NBT_Value>>);

		template<typename T>
			requires NBT_Surpported_Type<T>	&& NBT_Not_Null<T>
		NBT_Value(std::initializer_list<T> il) {
			std::vector<NBT_Value> value;
			for (auto& v : il) {
				value.push_back(v);
			}
			_value = std::move(value);
		}

		template<NBT_Surpported_Type T>
		NBT_Value& operator=(const T& value) {
			_value = value;
			return *this;
		}

		template<NBT_Type T>
		T& get() {
			return std::get<T>(_value);
		}

		NBT_Value& set_state(const int state) { _state |= state; return *this; }

		NBT_Value& unset_state(const int state) { _state &= ~state; return *this; }

		std::string to_string() const;

		bool if_use_gz() const { return _state & use_gz; }

		NBT_Value& add_tag(std::string, NBT_Value);

		NBT_Value& operator[](std::string);

	};

	std::ifstream& operator>>(std::ifstream&, NBT_Value&);

	constexpr Byte operator ""_b(unsigned long long v) {
		return Byte(v);
	}

	constexpr Short	operator ""_s(unsigned long long v) {
		return Short(v);
	}

	constexpr Int operator ""_i(unsigned long long v) {
		return Int(v);
	}

	constexpr Long operator ""_l(unsigned long long v) {
		return Long(v);
	}

	constexpr Float operator ""_f(long double v) {
		return Float(v);
	}

	constexpr Double operator ""_d(long double v) {
		return Double(v);
	}

	constexpr String operator ""_r(const char* v, size_t n) {
		return String(v);
	}

}
