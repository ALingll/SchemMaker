#include "NBT_Value.h"

#include <functional>
#include <string>
#include <algorithm>

namespace NBT {

	NBT::NBT_Value::NBT_Value(std::initializer_list<std::pair<std::string, NBT_Value>> ils)
	{
		Compound cmp;
		for (auto& pair : ils) {
			cmp[pair.first] = pair.second;
		}
		_value = std::move(cmp);
	}

	std::string NBT::NBT_Value::to_string() const
	{
		struct {
			std::string operator()(const End v) {
				return "";
			};
			std::string operator()(const Byte v) {
				return std::to_string(v) + "B";
			};
			std::string operator()(const Short v) {
				return std::to_string(v) + "S";
			};
			std::string operator()(const Int v) {
				return std::to_string(v);
			};
			std::string operator()(const Long v) {
				return std::to_string(v) + "L";
			};
			std::string operator()(const Float v) {
				return std::to_string(v) + "F";
			};
			std::string operator()(const Double v) {
				return std::to_string(v);
			};
			std::string operator()(const Byte_Array v) {
				std::string r{ "[B;" };
				if (!v.empty()) {
					r += std::to_string(v[0]) + "B";
					std::for_each(++v.begin(), v.end(),
						[&r](const Byte& a) {
							r += ",";
							r += std::to_string(a) + "B";
						}
					);
				}
				return r + "]";
			};
			std::string operator()(const String v) {
				return v;
			};
			std::string operator()(const List v) {
				std::string r{ "[" };
				if (!v.empty()) {
					r += v[0].to_string();
					std::for_each(++v.begin(), v.end(),
						[&r](const NBT_Value& a) {
							r += ",";
							r += a.to_string();
						}
					);
				}
				return r + "]";
			};
			std::string operator()(const Compound v) {
				std::string r{ "{" };
				r += (*v.begin()).first + ":";
				r += (*v.begin()).second.to_string();
				std::for_each(++v.begin(), v.end(),
					[&r](const std::pair<std::string, NBT_Value>& a) {
						r += ",\n";
						r += a.first + ":";
						r += a.second.to_string();
					}
				);
				return r + "}";
			};
			std::string operator()(const Int_Array v) {
				std::string r{ "[I;" };
				r += std::to_string(v[0]);
				std::for_each(++v.begin(), v.end(),
					[&r](const Int& a) {
						r += ",";
						r += std::to_string(a);
					}
				);
				return r + "]";
			};
			std::string operator()(const Long_Array v) {
				std::string r{ "[L;" };
				r += std::to_string(v[0]) + "L";
				std::for_each(++v.begin(), v.end(),
					[&r](const Long& a) {
						r += ",";
						r += std::to_string(a) + "L";
					}
				);
				return r + "]";
			};
		}str_make_visitor;
		return std::visit(str_make_visitor, _value);
	}

	NBT_Value::tag NBT_Value::get_tag() const {
		struct {
			tag operator()(End			) { return tag::TAG_End;		}
			tag operator()(Byte			) { return tag::TAG_Byte;		}
			tag operator()(Short		) { return tag::TAG_Short;		}
			tag operator()(Int			) { return tag::TAG_Int;		}
			tag operator()(Long			) { return tag::TAG_Long;		}
			tag operator()(Float		) { return tag::TAG_Float;		}
			tag operator()(Double		) { return tag::TAG_Double;		}
			tag operator()(Byte_Array	) { return tag::TAG_Byte_Array; }
			tag operator()(String		) { return tag::TAG_String;		}
			tag operator()(List			) { return tag::TAG_List;		}
			tag operator()(Compound		) { return tag::TAG_Compound;	}
			tag operator()(Int_Array	) { return tag::TAG_Int_Array;	}
			tag operator()(Long_Array	) { return tag::TAG_Long_Array; }
		}get_tag_visitor;
		return std::visit(get_tag_visitor, _value);
	}

	NBT_Value& NBT_Value::add_tag(std::string s, NBT_Value v)
	{
		auto& cmp = std::get<Compound>(_value);
		cmp[s] = v;
		return *this;
	}

	NBT_Value& NBT_Value::operator[](std::string s)
	{
		return std::get<Compound>(_value)[s];
	}

	std::ifstream& operator>>(std::ifstream& in, NBT_Value& v)
	{
		auto s = std::string(std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>());
		NBT_Value temp_v;

		if(v.if_use_gz())
			s = decompressString(s);

		std::istringstream is(s, std::ios::binary);
		is >> std::noskipws;
		auto current_tag = NBT_Value::get_binary_tag(is);
		std::string current_name{""};
		switch (current_tag)
		{
		case NBT_Value::tag::TAG_Compound: {
			auto temp_cmp = Compound();
			auto temp_name = NBT_Value::get_binary_string(is);
			temp_cmp[temp_name] = NBT_Value::get_binary_compound(is);
			temp_v = std::move(temp_cmp);
			break;
		}
		default:
			break;
		}

		v = std::move(temp_v);

		return in;
	}

	std::ofstream& operator<<(std::ofstream& out, NBT_Value& v) {
		std::ostringstream os(std::ios::binary);
		NBT_Value::put_binary_data(os, v);

		auto s = os.str();

		if (v.if_use_gz())
			s = decompressString(s);

		out << s;

		return out;
	}

	std::string decompressString(const std::string& compressed_data) {
		z_stream strm{};
		std::string uncompressed_data;

		// ��ʼ��z_stream�ṹ
		strm.zalloc = Z_NULL;
		strm.zfree = Z_NULL;
		strm.opaque = Z_NULL;
		strm.avail_in = 0;
		strm.next_in = Z_NULL;

		// ��ʼ����ѹ��
		int ret = inflateInit2(&strm, 16 + MAX_WBITS); // 16��ʾ�Զ����gzip����zlib��ʽ
		if (ret != Z_OK) {
			return "";
		}

		// ��������
		strm.avail_in = compressed_data.size();
		strm.next_in = reinterpret_cast<Bytef*>(const_cast<char*>(compressed_data.data()));

		// ��ѹ��ѭ��
		do {
			char outbuffer[1024]{};
			strm.avail_out = sizeof(outbuffer);
			strm.next_out = reinterpret_cast<Bytef*>(outbuffer);

			// ��ѹ������
			ret = inflate(&strm, Z_NO_FLUSH);
			if (ret < 0) {
				inflateEnd(&strm);
				return "";
			}

			// ����ѹ������ݿ�����uncompressed_data��
			uncompressed_data.append(outbuffer, sizeof(outbuffer) - strm.avail_out);
		} while (strm.avail_out == 0);

		// ������ѹ��
		inflateEnd(&strm);

		return uncompressed_data;
	}

	std::string compressString(const std::string& uncompressed_data) {
		z_stream strm;
		std::string compressed_data;

		// ��ʼ��z_stream�ṹ
		strm.zalloc = Z_NULL;
		strm.zfree = Z_NULL;
		strm.opaque = Z_NULL;

		// ��ʼ��ѹ��
		int ret = deflateInit2(&strm, Z_DEFAULT_COMPRESSION, Z_DEFLATED, 16 + MAX_WBITS, 8, Z_DEFAULT_STRATEGY);
		if (ret != Z_OK) {
			return "";
		}

		// ��������
		strm.avail_in = uncompressed_data.size();
		strm.next_in = reinterpret_cast<Bytef*>(const_cast<char*>(uncompressed_data.data()));

		// ѹ��ѭ��
		do {
			char outbuffer[1024];
			strm.avail_out = sizeof(outbuffer);
			strm.next_out = reinterpret_cast<Bytef*>(outbuffer);

			// ѹ������
			ret = deflate(&strm, Z_FINISH);
			if (ret < 0) {
				deflateEnd(&strm);
				return "";
			}

			// ��ѹ��������ݿ�����compressed_data��
			compressed_data.append(outbuffer, sizeof(outbuffer) - strm.avail_out);
		} while (strm.avail_out == 0);

		// ����ѹ��
		deflateEnd(&strm);

		return compressed_data;
	}

}